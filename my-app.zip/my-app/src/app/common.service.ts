import { Injectable } from '@angular/core';
import {Http,Response,Headers,RequestOptions} from '@angular/http'

import {Observable} from 'rxjs/Observable'
import 'rxjs/add/operator/map'
import 'rxjs/add/observable/of'
@Injectable()
export class CommonService {
  constructor(private http:Http) { }
  usn:string
  purchasedAdd1:any
  email:string
  GetProduct(){
    return this.http.get('http://localhost:8080/api/getProduct/').map((response:Response)=>response.json())
  }
  saveUser(user):Observable<any>{
    console.log("hellooooo")
    return this.http.post('http://localhost:8080/api/SaveUser/',user).map((response:Response)=>response.json())
    }
    saveAdd(user){
      return this.http.post('http://localhost:8080/api/SaveAdd/',user).map((response:Response)=>response.json())
    }
    parchasedAdd(id){
      console.log(id)
      this.purchasedAdd1=id;
      console.log(this.purchasedAdd1.name)
    }
    getPurchased():Observable<any>{
return Observable.of(this.purchasedAdd1)
    }
    GetUser(){
      return this.http.get('http://localhost:8080/api/getUser/').map((response:Response)=>response.json())
      }
      setUserName(user){
        localStorage.setItem(this.usn,user)
      }
      setEmail(email){
        this.email=email
      }
      getItem(){
        return this.email
      }
      deleteAdd(productname){
        return this.http.post('http://localhost:8080/api/deleteAdd/',{'productname':productname}).map((response:Response)=>response.json())
      }
}