import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-purchased',
  templateUrl: './purchased.component.html',
  styleUrls: ['./purchased.component.css']
})
export class PurchasedComponent implements OnInit {
purchased1:any;
ind=0;
  constructor(private newService: CommonService) { }

  ngOnInit() {

this.newService.getPurchased().subscribe(data=>{this.purchased1=data})
console.log(this.purchased1)
  }

}
