import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from "../common.service";
import { Router } from '@angular/router';
@Component({
  selector: 'app-post-advertisement',
  templateUrl: './post-advertisement.component.html',
  styleUrls: ['./post-advertisement.component.css']
})
export class PostAdvertisementComponent implements OnInit {
  cDuration: any = null;
  temp: Number = 0;
  errorMsg: string;
  myForm: FormGroup;
  Repdata;
  valbutton = "Save"
  flag1: boolean = true;
  flag: boolean = true;
  constructor(private fb: FormBuilder, private newService: CommonService, private router: Router) {
    this.myForm = fb.group({
      productname: ['', Validators.required],
      price: ['', Validators.required],
      description: ['', Validators.required],
      name:['',Validators.required],
      numb:['',Validators.required],
      email :['',Validators.required],
      photo: ['', Validators.required],
    })
  }

  ngOnInit() {
  }
  AddPost(user) {
    var Regex = /^[a-zA-Z.,;\s]+$/
    var price = this.myForm.get('price').value;
    var name = this.myForm.get('productname').value;
    var phoneRegex=/^[0-9]{10}$/
    var numb=this.myForm.get('numb').value
    var description=this.myForm.get('description').value;
    if (this.myForm.valid) {
      if (price > 0 && name.match(Regex) && description.match(Regex) && numb.match(phoneRegex)) {
        alert("valid")
        user.mode=this.valbutton;
        this.newService.saveAdd(user).subscribe(data=>{alert(data.data);
        this.ngOnInit();
        })
        this.myForm.reset()
        this.router.navigate(['signin'])
//         this.router.navigateByUrl('/signin', {skipLocationChange: true}).then(()=>
// this.router.navigate(["loggedinComponent"]));
      }

      else {
        alert("Given name or price or description pattern is invalid")
      }
    }
    else {
      this.flag1=false;
      alert("not valid")
    }
    
  }
  onCancel() {
    this.router.navigate(['signin'])
  }
}
