import { Component, OnInit } from '@angular/core';

import { CommonService } from '../common.service';
import { Router } from '@angular/router';
import { ProductData } from '../product-data'
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  Repdata;
  flag1 = true
  myForm: FormGroup;
  valbutton = "Save"
  constructor(private fb: FormBuilder, private newService: CommonService, private router: Router) {
    this.myForm = fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      cpassword: ['', Validators.required],
      mobile: ['', Validators.required],
      address: ['', Validators.required]
    })
  }

  ngOnInit() {
  }
  AddCourse(user) {
    var uRegex = /^[a-zA-Z0-9/s@.]+@capgemini.com$/
    // var passwordRegex = /^[a-zA-Z0-9.@$]{7,10}$/
    var mobileRegex = /^[0-9]{10}$/
    var regex = /^[a-zA-Z0-9@.$]$/
    var password = this.myForm.get('password').value;
    var password1 = this.myForm.get('cpassword').value;
    var mobile = this.myForm.get('mobile').value
    var name = this.myForm.get('username').value;
    var address = this.myForm.get('address').value
    if (this.myForm.valid) {
      if ((name.match(uRegex))) {
        if (mobile.match(mobileRegex)) {
          if(password==password1){
          user.mode = this.valbutton;
          this.newService.saveUser(user).subscribe(data => {
            alert(data.data);
            // this.ngOnInit();
          })
          alert("successfully saved")
          this.router.navigate(['userlogin'])
        }
        else{
          alert("password is incorrect")
        }
      }
    }
      else {
        this.flag1 = false
        alert(" Enter valid details")
      }

    }
    else {
      this.flag1 = false
      alert("Enter details correctly")
    }
  }
  // var uRegex = /^[a-zA-Z0-9/s@.]+@capgemini.com$/
  // // var passwordRegex = /^[a-zA-Z0-9.@$]{7,10}$/
  // var mobileRegex = /^[0-9]{10}$/
  // var regex=/^[a-zA-Z0-9@.$]$/
  // // var password = this.myForm.get('password').value;
  // // var password1 = this.myForm.get('cpassword').value;
  // var mobile = this.myForm.get('mobile').value
  // var name = this.myForm.get('username').value;
  // var address=this.myForm.get('address').value
  // AddCourse(user) {
  //   this.flag1 = true;
  //   this.temp = 0;
  //   var usernameRegex = /^[a-zA-Z.]+[0-9]*@capgemini.com$/
  //   var passwordRegex = /^[a-zA-Z0-9.@$]{7,10}$/
  //   var password = this.myForm.get('password').value;
  //   var username = this.myForm.get('username').value.toLowerCase();
  //   if (this.myForm.valid) {
  //     if ((username.match(usernameRegex)) && (password.match(passwordRegex))) {
  //       this.errorMsg = "Username or Password is incorrect"
  //       for (let k of this.registeredData) {
  //         if (k.name == username) {
  //           if (k.password == password) {
  //             this.errorMsg = "Logged in Scuccesfully"

  //             this.router.navigate(['signin'])
  //           }
  //         }
  //       }
  //       alert(this.errorMsg)
  //     }

  //     else {
  //       this.flag1 = false
  //     }

  //   }

  //   else {
  //     this.flag1 = false
  //     alert("not valid")
  //   }
  // }
}
