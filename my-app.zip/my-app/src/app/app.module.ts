import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from "@angular/forms"
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import {Routes,RouterModule} from '@angular/router'
import { CommonService } from './common.service';
import {HttpModule} from "@angular/http";
import { LoginComponent } from './login/login.component';
import { LoggedinComponent } from './loggedin/loggedin.component';
import { PostAdvertisementComponent } from './post-advertisement/post-advertisement.component';
import { PurchasedComponent } from './purchased/purchased.component';
import{ HomescreenComponent } from './homescreen/homescreen.component'
// import { BuyAdvertisementComponent } from './buy-advertisement/buy-advertisement.component'
const appRoutes:Routes=[
  {path:'',component:HomescreenComponent},
  {path:'add',component:HomeComponent},
  {path:'userlogin',component:LoginComponent},
  {path:'signin',component:LoggedinComponent},
    {path:'post',component:PostAdvertisementComponent},
    // {path :'purchased',component:BuyAdvertisementComponent}
    {path:'purchased',component:PurchasedComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    LoggedinComponent,
    PostAdvertisementComponent,
    PurchasedComponent,
    HomescreenComponent
    // BuyAdvertisementComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(appRoutes),FormsModule,HttpModule,ReactiveFormsModule
  ],
  providers: [CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
