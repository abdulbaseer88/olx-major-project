import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from "../common.service";
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  cDuration: any = null;
  temp: Number = 0;
  errorMsg: string;
  myForm: FormGroup;
  Repdata;
  registeredData; 
  flag1: boolean = true;
  flag: boolean = true;
  constructor(private fb: FormBuilder, private newService: CommonService, private router: Router) {

    this.myForm = fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    })
  }
  ngOnInit() {
    this.newService.GetUser().subscribe(data => this.registeredData = data)
  }
  AddCourse(user) {
    this.flag1 = true;
    this.temp = 0;
    var usernameRegex = /^[a-zA-Z.]+[0-9]*@capgemini.com$/
    var passwordRegex = /^[a-zA-Z0-9.@$]{7,10}$/
    var password = this.myForm.get('password').value;
    var username = this.myForm.get('username').value.toLowerCase();
    if (this.myForm.valid) {
      if ((username.match(usernameRegex)) && (password.match(passwordRegex))) {
        this.errorMsg = "Username or Password is incorrect"
        for (let k of this.registeredData) {
          if (k.username == username) {
            if (k.password == password) {
              this.errorMsg = "Logged in Scuccesfully"
              
              this.router.navigate(['signin'])
            }
          }
        }
        alert(this.errorMsg)
      }

      else {
        this.flag1 = false
      }

    }
   
    else {
      this.flag1 = false
      alert("not valid")
    }
    this.newService.setUserName(username)
    // this.newService.setEmail(this.registeredData.username)
  }
  onSignupClick() {
    this.router.navigate(['add'])
  }
}
