const express = require("express")
const bodyParser = require("body-parser")
const path= require ("path");
const mongo= require("mongoose");
// const productData = require("../my-app/src/app/product-data")
var session = require('express-session');
var db= mongo.connect("mongodb://127.0.0.1:27017/mydb",function(err,response){
    if(err){
        console.log(err)
    }
    else{
        console.log("connected to"+db,"+",response);
    }
})


var app=new express();

app.use(bodyParser())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))

app.use(function (req,res,next){
    res.setHeader("Access-Control-Allow-Origin","http://localhost:4200")
    res.setHeader("Access-Control-Allow-Methods","GET,POST,OPTIONS,PUT,DELETE,PATCH")
    res.setHeader("Access-Control-Allow-Headers","X-Requested-With,content-type")
    res.setHeader("Access-Control-Allow-Credentials",true)

    next();
});
  

var Schema=mongo.Schema;

var UsersSchema= new Schema({
    username:{type:String},
    password:{type:String},
    cpassword:{type:String},
    mobile:{type:String},
    address:{type:String}
});

var ProductSchema =new Schema({
    productname:{type:String,unique:true},
    price:{type:Number},
    description:{type:String},
    name:{type:String},
    numb:{type:String},
    email :{type:String}
    // photo:{type:str}
})

var model= mongo.model("user",UsersSchema);
var products=mongo.model("products",ProductSchema)
app.post("/api/SaveUser",function(req,res){
    var mod= new model(req.body);
    if(req.body.mode=="Save"){
        mod.save(function(err,data){
            if(err){
                res.send(err)
            }
            else{
                res.send({data:"record has been  stored successfully"})
            }
        })
        
    }
});

app.post("/api/SaveAdd",function(req,res){
    var mod= new products(req.body);
    if(req.body.mode=="Save"){
        mod.save(function(err,data){
            if(err){
                res.send(err)
            }
            else{
                res.send({data:"record has been  stored successfully"})
                
            }
        })
        
    }
})

console.log("record got jhdgksfhdg")

app.get("/api/getProduct/",function(req,res){
    products.find({},function(err,data){
        if(err){
            res.send(err)
        }
        else
        {
            console.log("hoooo")
            res.send(data)

        }
    })
});

app.post("/api/deleteAdd",function(req,res){
    products.remove({productname:req.body.productname},function(err){
        if(err){
            res.send(err)
        }
        else{
            res.send({data:"data has been puchased"})
        }
    })
})

app.get("/api/getUser",function(req,res){
    model.find({},function(err,data){
        if(err){
            res.send(err)
        }
        else
        {
            console.log("hoooo")
            res.send(data)

        }
    })
});



app.get('/logout', (req, res)=> {
    req.session.destroy(function(err){  
        if(err){  
            console.log(err); 
            Response.errorResponse(err.message,res); 
        }  
        else  
        {  
            Response.successResponse('User logged out successfully!',res,{}); 
        }  
    });
});
app.listen(8080,function(){
    console.log("yo  listen   8080")
})
